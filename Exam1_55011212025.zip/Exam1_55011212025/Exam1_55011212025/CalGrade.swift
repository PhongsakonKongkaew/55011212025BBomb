//
//  CalGrade.swift
//  Exam1_55011212025
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import Foundation
class CalGrade{
    var num1:Double
    var num2:Double
    var num3:Double
    init(num1:Double,num2:Double,num3:Double){
        self.num1 = num1
        self.num2 = num2
        self.num3 = num3
    }
    
}